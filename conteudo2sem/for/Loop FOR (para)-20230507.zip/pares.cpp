//imprimindo apenas numeros pares em uma sequencia
#include<iostream>
using namespace std;

int main(){
	for(int i=2;i<=215;i+=2){
		cout<<i<<endl;
	}
}
