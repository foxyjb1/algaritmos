//decrementacao no loop for
#include<iostream>
using namespace std;

int main(){
	for(int i = 100;i>=0; i--){
		cout<<i<<endl;
	}
}
